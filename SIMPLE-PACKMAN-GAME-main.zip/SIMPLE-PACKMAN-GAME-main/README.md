# SIMPLE-PACKMAN
The game.cpp program has been run in Dev C ++. Please install the Graphics.h library as in the video.
 https://www.youtube.com/watch?v=H5bjXTz-HHo&t=66s
